import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import React, { useState } from 'react';
import play from './Play.png';
import plus from './Plus.png';

function App() {

const [Player, setPlayer] = useState([])
const[newPlayer, setNewPlayer] = useState('')
const [minuts,setMinuts] = useState('10')
const [seconds,setSeconds] = useState('00')

let turn = '#P1';
const ChangeTurn = () =>{
  if(turn === '#P2'){
    turn = '#P1'
    document.querySelector('#Sur2').style.opacity = 1;
    document.querySelector('#Sur2').style.pointerEvents = 'all';
    document.querySelector('.PBlack').style.backgroundColor = 'var(--hback1)';
    document.querySelector('#Sur1').style.opacity = 0;
    document.querySelector('#Sur1').style.pointerEvents = 'none';
    document.querySelector('.PWhite').style.backgroundColor = 'transparent';

  }
  else{
    turn = '#P2'
    document.querySelector('#Sur1').style.opacity = 1;
    document.querySelector('#Sur1').style.pointerEvents = 'all';
    document.querySelector('.PWhite').style.backgroundColor = 'var(--hback2)';
    document.querySelector('#Sur2').style.opacity = 0;
    document.querySelector('#Sur2').style.pointerEvents = 'none';
    document.querySelector('.PBlack').style.backgroundColor = 'transparent';
  }
}


let P1StartMins = parseFloat(minuts);
let P1StartSeconds = parseFloat(seconds);
let P2StartMins = parseFloat(minuts);
let P2StartSeconds = parseFloat(seconds);

let End = false;
const calc = () => {

if(End === false){
  if(turn === '#P2'){
    if(P1StartSeconds === 0){
      P1StartSeconds = 59;
      P1StartMins -= 1;
      document.querySelector('#P1').innerHTML = P1StartMins+":"+P1StartSeconds; 
    }else{
      P1StartSeconds -=1;
      if(P1StartSeconds <= 9){
        document.querySelector('#P1').innerHTML = P1StartMins+":0"+P1StartSeconds
      }else{
      document.querySelector('#P1').innerHTML = P1StartMins+":"+P1StartSeconds;
      }
      if(P1StartMins===0 && P1StartSeconds===0){
        setTimeout(end,0);
      }
      
    }
  }else{
    if(P2StartSeconds === 0){
      P2StartSeconds = 59;
      P2StartMins -= 1;
      document.querySelector('#P2').innerHTML = P2StartMins+":"+P2StartSeconds; 
    }else{        
      P2StartSeconds -=1;
      if(P2StartSeconds <= 9){
        document.querySelector('#P2').innerHTML = P2StartMins+":0"+P2StartSeconds
      }else{
      document.querySelector('#P2').innerHTML = P2StartMins+":"+P2StartSeconds;
      }
      if(P2StartMins===0 && P2StartSeconds===0){
        setTimeout(end,0);
      }
    }
  }
}
}


const end = () => {
  End = true;
  document.querySelector('.Main3').style.display ='flex';
  setTimeout(() => {
    Jump()
  }, 4000);
  if(turn === '#P1'){
    let num2 = 0
    const playerToUpdate = num2; 
    setPlayer(prevPlayers => prevPlayers.map((player, index) => {
      if (index === playerToUpdate) {
        document.querySelector('#Winner').innerHTML = 'White Won!';
        return {
          ...player,
          Wins: player.Wins + 1,
        };
      } else {
        return {
          ...player,
          ['Defeat']: player['Defeat'] + 1,
        };
      }
    }));
  }else{
    let num2 = 1
    const playerToUpdate = num2; 
    setPlayer(prevPlayers => prevPlayers.map((player, index) => {
      if (index === playerToUpdate) {
        document.querySelector('#Winner').innerHTML = 'Black Won!';
        return {
          ...player,
          Wins: player.Wins + 1,
        };
      } else {
        return {
          ...player,
          ['Defeat']: player['Defeat'] + 1,
        };
      }
    }));
  }
}

const StartHelp = () => { //tu ,\usisz se cos zrobic
  document.querySelector('.Help').style.display ='flex';
  document.querySelector('.Help').style.top ='50%';
}
const Exit = () => {
  document.querySelector('.Help').style.display ='none';
  document.querySelector('.Help').style.top ='150%';
}

const Tie = () => {
  End = true;
  document.querySelector('.Main3').style.display ='flex';
  setTimeout(() => {
    Jump()
  }, 4000);

  setPlayer(prevPlayers => prevPlayers.map((player, index) => {
    document.querySelector('#Winner').innerHTML = 'Tie!';
    return {
      ...player,
      Wins: player.Wins + 0.5,
    };
  }));
}

const Jump = () => {
  document.querySelector('.Main2').style.display ='none';
  document.querySelector('.Help').style.display ='none';
  document.querySelector('.Main3').style.display ='none';
  document.querySelector('.Start-Game').style.pointerEvents = 'all';
  document.querySelector('.Bease').style.pointerEvents= 'none';
  document.querySelector('.Tie').style.display = 'none';
  document.querySelector('.Tie').style.opacity = 0;
  document.querySelector('.PWhite').style.backgroundColor = 'transparent';
  document.querySelector('.PBlack').style.backgroundColor = 'transparent';
  
}






const addPlayer = () => {
  if (newPlayer){
    let num = Player.length + 1;
    var CurrentTurn = " (White)";
    if (Player.length === 1 && CurrentTurn === ' (White)'){
      CurrentTurn = ' (Black)';
    }
    let newEntry = {"id": num, "Wins": 0, "Name": newPlayer + CurrentTurn, "Defeat": 0}
    setPlayer([...Player, newEntry]);
    setNewPlayer('');
    if (document.querySelector('.Player-Name-Input').value !== '') {
      document.querySelector('.Player-Name-Input').value = "";
      }
    if(Player.length >= 1){
      document.querySelector('.Start-Game').style.opacity = 1;
      document.querySelector('.Start-Game').style.transition = 'all 2s';
      document.querySelector('.Start-Game').style.pointerEvents = 'all';
      turn = '#P1';
    }
  }
}
const changeMenu = () => {
  document.querySelector('.Main2').style.display ='flex';
  document.querySelector('.Help').style.display ='none';
  document.querySelector('.Main').style.paddingTop = '0px';
  document.querySelector('.Main2 .Start-Game').style.opacity = 1;
  document.querySelector('#Sur1').style.opacity = 0;
  document.querySelector('#Sur2').style.opacity = 0;
  document.querySelector('.Main2 #P1').style.opacity = 0;
  document.querySelector('.Main2 #P2').style.opacity = 0;
  if(P1StartSeconds !== 0){
    document.querySelector('#P1').innerHTML = P1StartMins+':'+P1StartSeconds;
  document.querySelector('#P2').innerHTML = P2StartMins+':'+P2StartSeconds;
  }else{
    document.querySelector('#P1').innerHTML = P1StartMins+':'+P1StartSeconds+'0';
  document.querySelector('#P2').innerHTML = P2StartMins+':'+P2StartSeconds+'0';
  }
  document.querySelector('.Main2 .Start-Game').style.pointerEvents = 'all';
}
const gameStart = () => {
  document.querySelector('.Main2 .Start-Game').style.pointerEvents = 'none';
  document.querySelector('.Main2 .Start-Game').style.opacity = 0;
  document.querySelector('.Bease').style.pointerEvents= 'all';
  setInterval(calc,1000);
  End= false;
  setTimeout(() => {
    title()
  }, 100);

}
const title = () =>{
  document.querySelector('.Tie').style.opacity = 1;
  document.querySelector('.Tie').style.display = 'flex';
  document.querySelector('#P2').style.opacity = 1;
  document.querySelector('#P1').style.opacity = 1;
  if(P1StartSeconds >= 60){
    P1StartSeconds = 59;
    document.querySelector('#P1').innerHTML = P1StartMins+":"+P1StartSeconds; 
  }
  if(P2StartSeconds >= 60){
    P2StartSeconds = 59;
    document.querySelector('#P2').innerHTML = P2StartMins+":"+P2StartSeconds; 
  }
  if(P1StartSeconds <= 9){
    document.querySelector('#P1').innerHTML = P1StartMins+":0"+P1StartSeconds
  }
  if(P2StartSeconds <= 9){
    document.querySelector('#P2').innerHTML = P2StartMins+":0"+P2StartSeconds
  }
}

  return (
    <div className="Main">
      <h2 className='Main-Title'>Chess player List</h2>
      <div className='Playnr-Name-Input-Container'>{Player && Player.length === 2? '' : <div className='Inp'><input maxlength="8" onChange={ (e) => setNewPlayer(e.target.value)} className='Player-Name-Input' placeholder='Write player name'></input><button className='Press-add' onClick={addPlayer}><img src={plus}></img></button></div>}</div>
      <div className='Player-List'>
        {Player && Player.map((Player, index) => {
          return(
            <React.Fragment key={Player.id}>
              <div className='Player-Container'>
                <span className='Player-Wins'>{Player.Wins}</span>
                <span className='Player-Name'>{Player.Name}</span>
                <span className='Player-Defeat'>{Player['Defeat']}</span>
              </div>
            </React.Fragment>
          )
        })}
      </div>
      <button className='Start-Game' onClick={changeMenu}><img src={play}></img></button>
      
     
      <div className='Timer-Container'>
        <input type="number" onChange={(e) => setMinuts(e.target.value)} className='Time-Input' maxlength="2" placeholder='10m'></input>
        <h1>:</h1>
        <input type="number" onChange={(e) => setSeconds(e.target.value)} className='Time-Input' maxlength="2" placeholder='00s'></input>
      </div>
      <button className='Help-btt' onClick={StartHelp}><h1>?</h1></button>
      
      <div className="Main2">
        <div className='Bas'>
          <div className='Player-List2'>
            {Player && Player.map((Player, index) => {
              return(
                <React.Fragment key={Player.id}>
                  <div className='Player-Container2' id={"Pl"+Player.id}>
                    <span className='Player-Wins' id={'#PE'+Player.id}>{Player.Wins}</span>
                    <span className='Player-Name'>{Player.Name}</span>
                    <span className='Player-Defeat'>{Player['Defeat']}</span>
                  </div>
                </React.Fragment>
              )
            })}
          </div>
          <button className="Bease" onClick={ChangeTurn}>
            <div className="PWhite"><h1 className='Time'><h2 id='P1'>{P1StartMins}:{P1StartSeconds}</h2></h1><button onClick={end} className='Surr' id='Sur1'>Give up</button></div>
            <div className='Pause'>
              <button className='Tie' onClick={Tie}>Tie</button>
              <button className='Start-Game' onClick={gameStart}><img src={play}></img></button></div>
            <div className="PBlack"><h1 className='Time'><h2 id='P2'>{P2StartMins}:{P2StartSeconds}</h2></h1><button onClick={end} className='Surr' id='Sur2'>Give up</button></div>
          </button>
        </div>
      </div>
      <div className='Main3'>
            <div className='Winner-Container2'>
              <div className='BackEnd'></div>
              <h2 id='Winner'>Congrats,u found a bug</h2>
              </div>
      </div>

      <div className='Help'>
        
        <div className='Help-head'>
          <h1>Game Clock Rules</h1>
          <ul>
            <li>Enter player names</li>
            <li>Select game time</li>
            <li>Click the start button after entering the players to start the game</li>
            <li>During the game, clicking changes the player's turn</li>
            <li>You can give up by clicking the "give up" button</li>
            <li>You win when your opponent gives up or time runs out</li>
          </ul>
          <button className='Exit' onClick={Exit}><h1>X</h1></button>
        </div>
        <div className='BackHelp'></div>
      </div>
      
      


    </div>  
  );
}

export default App;
